#ingredientes.py
#Author --> Liz

ingredientes_vegetales=['tomate','aceitunas','champiñones']
ingredientes_proteicos=['pollo','vacuno','carne vegetal']
tipo_masa=['tradicional','delgada']