from ClsAbsTienda import Tienda
from ClsProducto import Producto

class Restaurante(Tienda):
    

    def ingresar_producto(self, nombre:str, precio: int, stock: int =0):
        producto=Producto(nombre,precio,stock)#revisar dejar en cero
        self.lista_productos.append(producto)

    def listar_producto(self):
        lista=[]
        for producto in self.lista_productos:
            cadena=producto.nombre+' '+str(producto.precio)
            lista.append(cadena)
        return 

    def realizar_venta(self, nombre: str, cantidad: int):
        pass